/**
 * 
 */
package com.webmethods.caf;

/**
 * @author bggov
 *
 */
public class Wm_permissions_sample extends com.webmethods.caf.faces.bean.BaseApplicationBean 
{
	public Wm_permissions_sample()
	{
		super();
		setCategoryName( "CafApplication" );
		setSubCategoryName( "wm_permissions_sample" );
	}
}