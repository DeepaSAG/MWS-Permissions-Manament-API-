/**
 * 
 */
package com.webmethods.caf.wmpermissiontest;

/**
 * @author bggov
 *
 */

import javax.portlet.PortletPreferences;

public class WmPermissionTest  extends   com.webmethods.caf.faces.bean.BaseFacesPreferencesBean {

	public static final String[] PREFERENCES_NAMES = new String[] {};
	private com.webmethods.caf.Wm_permissions_sample wm_permissions_sample = null;
	
	/**
	 * Create new preferences bean with list of preference names
	 */
	public WmPermissionTest() {
		super(PREFERENCES_NAMES);
	}
	
	/**
	 * Call this method in order to persist
	 * Portlet preferences
	 */
	public void storePreferences() throws Exception {
		updatePreferences();
		PortletPreferences preferences = getPreferences();
		preferences.store();
	}

	public com.webmethods.caf.Wm_permissions_sample getWm_permissions_sample()  {
		if (wm_permissions_sample == null) {
		    wm_permissions_sample = (com.webmethods.caf.Wm_permissions_sample)resolveExpression("#{Wm_permissions_sample}");
		}
		return wm_permissions_sample;
	}
}