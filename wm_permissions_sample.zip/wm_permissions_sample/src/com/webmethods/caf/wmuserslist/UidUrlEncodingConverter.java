package com.webmethods.caf.wmuserslist;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import com.webmethods.rtl.encode.URLEncoder;

/**
 * Used for URL-friendly convertion of principal uid's. 
 * @author bgsge
 *
 */
public class UidUrlEncodingConverter implements Converter {

    public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) {
        return this.getAsString(arg0, arg1, arg2);

    }

    public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) {
        String str = ((String) arg2);

        String encodedPrincipalURI = URLEncoder.encoder().encode(str.substring(str.lastIndexOf('/') + 1));

        str = str.substring(0, str.lastIndexOf('/') + 1) + encodedPrincipalURI;

        return str;

    }

}
