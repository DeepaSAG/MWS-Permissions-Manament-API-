package com.webmethods.caf.wmuserslist;

import java.util.Map;

import com.webmethods.portal.bizPolicy.impl.Context;

import com.webmethods.portal.PortalException;
import com.webmethods.portal.bizPolicy.IContext;
import com.webmethods.portal.bizPolicy.ITraits;
import com.webmethods.portal.bizPolicy.biz.IBizPolicyManager;
import com.webmethods.portal.bizPolicy.biz.IBizPolicyNames;
import com.webmethods.portal.bizPolicy.biz.dir.IDirServiceBizPolicy;
import com.webmethods.portal.bizPolicy.biz.system.ISystemPolicy;
import com.webmethods.portal.bizPolicy.impl.PrincipalData;
import com.webmethods.portal.bizPolicy.impl.Traits;
import com.webmethods.portal.mech.IMechanicsManager;
import com.webmethods.portal.mech.IMechanicsNames;
import com.webmethods.portal.mech.dir.IDirSystemMechanics;
import com.webmethods.portal.service.dir.IDirConstants;
import com.webmethods.portal.service.dir.IDirPrincipal;
import com.webmethods.portal.service.dir.IDirPrincipalList;
import com.webmethods.portal.service.dir.IDirService;
import com.webmethods.portal.service.dir.IDirSystem;
import com.webmethods.portal.service.dir.IDirUser;
import com.webmethods.portal.service.global.IGlobalProvider;
import com.webmethods.portal.service.meta2.thing.IThingID;
import com.webmethods.portal.service.meta2.thing.IThingIDList;
import com.webmethods.portal.system.PortalSystem;

public class UserInfo {
    public IDirSystemMechanics getDirectoryMechanics() throws PortalException {
        IDirSystemMechanics directoryMechanics = (IDirSystemMechanics) getMechancisManager().getMechanics(IMechanicsNames.DIRECTORY_SYSTEM);
        return directoryMechanics;
    }

    public IMechanicsManager getMechancisManager() throws PortalException {
        return (IMechanicsManager) PortalSystem.getMechanicsProvider();
    }

	protected IContext createContext(String uid, boolean isAdmin, boolean isAnonymous) throws PortalException {
        IDirUser user = (IDirUser)getDirectoryMechanics().lookupPrincipalByID(uid, IDirSystem.TYPE_USER);
        if (user == null) { // user does not exist
        	return null; 
        }

        // initialize user
        IDirSystem dirSystem = (IDirSystem) PortalSystem.getDirectoryProvider();
        IDirService dirService = dirSystem.getDirectoryServiceFromThingID(user.getDirectoryServiceThingID());
        dirService.getDirPrincipalProvider().initializePrincipal(user.getURI());

        // populate context
        PrincipalData principalData = new PrincipalData();
        principalData.setAuthentication(!isAnonymous);
        principalData.setDN(user.getDN());
        principalData.setDomain(user.getDirectoryServiceThingID().getThing().getName(((IGlobalProvider)PortalSystem.getGlobalProvider()).getPortalSystemLocale().getLanguage()));
        principalData.setIsAdminSession(isAdmin);
        principalData.setIsAnonymous(isAnonymous);
        principalData.setUri(user.getURI().toString());
        principalData.setUserID(user.getDirectoryPrincipalID());
        principalData.setUserName(user.getName());

        IContext context = new Context() {
        };
        
        context.initialize(principalData);
        context.setTraits(new Traits(ITraits.ALL));

        // create user folders
        IBizPolicyManager bizPolicyManager = (IBizPolicyManager) PortalSystem.getBizPolicyProvider();
        ISystemPolicy systemPolicy = (ISystemPolicy) bizPolicyManager.getBizPolicy(IBizPolicyNames.SYSTEM);

        ITraits cachedTraits = context.getTraits();
        context.setTraits(Traits.ACCESS_FREE_TRAITS);
        systemPolicy.createUserFolders(context);
        context.setTraits(cachedTraits);

        return context;
    }

	public void getUserInformation() {
		try {
//			IContextProvider contextProvider = (IContextProvider) PortalSystem
//					.getContextProvider();
//			IContext mwsContext = contextProvider.getCurrentContextForThread();
			IContext mwsContext = createContext("sysadmin", false, false);
			IDirSystem dirSystem = (IDirSystem) PortalSystem
					.getDirectoryProvider();
			IBizPolicyManager bizMgr = (IBizPolicyManager) PortalSystem
					.getBizPolicyProvider();
			IDirServiceBizPolicy dirSvcPolicy = (IDirServiceBizPolicy) bizMgr
					.getBizPolicy(IBizPolicyNames.DIRECTORY_SERVICE);

			IDirPrincipalList foundUsers = dirSvcPolicy.searchDirectory(
					mwsContext, (IThingID) dirSystem
							.getSystemDirectoryService().getURI(),
					IDirConstants.TYPE_USER, "");
			if (foundUsers != null) {
				System.out.println("UserID   | User Name      | Role Name    | Role Description    | Status of the user ");
				for (int i = 0; i < foundUsers.size(); i++) {
					Object object = foundUsers.get(i);
					IThingIDList tidList = dirSystem.getRoleSystem().getRoles(((IDirPrincipal) object).getDirectoryPrincipalID());
					Map<Object, Object> userProps = ((IDirPrincipal) object).getProperties();
					String uid = userProps.get("UID").toString();
					String uname = userProps.get("fullName").toString();
					String ustatus = userProps.get("disabled").toString();
					for (int j = 0; j < tidList.size(); j++) {
						String rname = tidList.getThingID(j).getThing().getName();
						String rdesc = tidList.getThingID(j).getThing().getDescription();

						System.out.println("" + uid + " | " + uname + " | " + rname + " | " + rdesc + " | " + ustatus);
					}
				}
			}
		} catch (PortalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}