package com.webmethods.caf.wmuserslist;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.mutable.MutableInt;

import com.webmethods.caf.common.StringTools;
import com.webmethods.caf.faces.data.dir.IPrincipalProvider;
import com.webmethods.caf.faces.data.dir.PrincipalModelFactory;
import com.webmethods.caf.faces.data.tree.object.BoundChildrenTreeContentProvider;
import com.webmethods.caf.faces.data.tree.object.NodeTreeContentProvider;
import com.webmethods.portal.service.access.Ace;
import com.webmethods.portal.service.access.IAclManager.AcePropertyDescriptor;


public class WmUsersEditPermissionsView  extends   com.webmethods.caf.faces.bean.BasePortletPageBean {

	/**
	 * Determines if a de-serialized file is compatible with this class.
	 *
	 * Maintainers must change this value if and only if the new version
	 * of this class is not compatible with old versions. See Sun docs
	 * for <a href=http://java.sun.com/j2se/1.5.0/docs/guide/serialization/spec/version.html> 
	 * details. </a>
	 */
	private static final long serialVersionUID = 1L;
	private static final String[][] INITIALIZE_PROPERTY_BINDINGS = new String[][] {
	};
	private com.webmethods.caf.wmuserslist.WmUsersList wmUsersList = null;
	private com.webmethods.caf.wmuserslist.UserInfo userInfo = null;
	private com.webmethods.portal.service.access.Ace ace = null;
	private static final String[][] ACE_PROPERTY_BINDINGS = new String[][] {
	};
	private com.webmethods.portal.service.access.impl.BaseAclManager aclManager = null;
	private static final String[][] ACLMANAGER_PROPERTY_BINDINGS = new String[][] {
	};

	/**
	 * Initialize page
	 */
	public String initialize() {
		try {
		    resolveDataBinding(INITIALIZE_PROPERTY_BINDINGS, null, "initialize", true, false);

			return OUTCOME_OK;
		} catch (Exception e) {
			error(e);
			log(e);
			return OUTCOME_ERROR; 
		}	
	}

	public com.webmethods.caf.wmuserslist.WmUsersList getWmUsersList()  {
		if (wmUsersList == null) {
		    wmUsersList = (com.webmethods.caf.wmuserslist.WmUsersList)resolveExpression("#{WmUsersList}");
		}
		return wmUsersList;
	}

	public com.webmethods.caf.wmuserslist.UserInfo getUserInfo()  {
		if (userInfo == null) {
			userInfo = (com.webmethods.caf.wmuserslist.UserInfo)resolveExpression("#{UserInfo}");
		}
		return userInfo;
	}

	/**
	 * Determines if a de-serialized file is compatible with this class.
	 *
	 * Maintainers must change this value if and only if the new version
	 * of this class is not compatible with old versions. See Sun docs
	 * for <a href=http://java.sun.com/j2se/1.5.0/docs/guide/serialization/spec/version.html> 
	 * details. </a>
	 */

	public com.webmethods.portal.service.access.Ace getAce()  {
		if (ace == null) {
			ace = new com.webmethods.portal.service.access.Ace();
		}
	
		return ace;
	}

	public void setAce(com.webmethods.portal.service.access.Ace ace)  {
		aceProperties = null;
		acePropertiesProvider = null;
		
		// create a copy to correctly handle cancelling out of the page
		this.ace = (Ace)ace.clone();
	}

	public com.webmethods.portal.service.access.impl.BaseAclManager getAclManager()  {
		return aclManager;
	}

	public void setAclManager(com.webmethods.portal.service.access.impl.BaseAclManager aclManager)  {
		this.aclManager = aclManager;
	}
	
	AceProperty[] aceProperties;
	Map<String, String> acePropertiesIDMap = new HashMap<String, String>();
	public AceProperty[] getAceProperties() throws Exception {
		if (aceProperties == null) {
			acePropertiesIDMap.clear();
			
			List<AcePropertyDescriptor> acePropertyDescriptors = getAclManager().getAcePropertyDescriptors(getResources());
			List<AceProperty> l = new ArrayList<AceProperty>();
			MutableInt id = new MutableInt(0);
			for (AcePropertyDescriptor ad: acePropertyDescriptors) {
				l.add(createAceProperty(ad, id));
			}

			aceProperties = l.toArray(new AceProperty[] {});
		}

		getUserInfo().getUserInformation();

		return aceProperties;
	}
	
	ArrayList<String> resources;
	
	public ArrayList<String> getResources() {
		return resources;
	}

	public void setResources(ArrayList<String> resources) {
		this.resources = resources;
	}
	
	String[] selectedPrincipals;
	public String[] getSelectedPrincipals() {
		return selectedPrincipals;
	}

	public void setSelectedPrincipals(String[] selectedPrincipals) {
		this.selectedPrincipals = selectedPrincipals;
	}
	
	private AceProperty createAceProperty(AcePropertyDescriptor ad, MutableInt id) throws Exception {
		AceProperty ap = new AceProperty(getAce(), id.toString());
		// store in the ID map
		ap.getDisplayName();
		acePropertiesIDMap.put(ad.getName(), id.toString());
		
		id.increment();
		
		ap.setParent(ad.getParent());
		ap.setName(ad.getName());
		ap.setAllowValue(ad.isAllowValue());
		ap.setDisplayName(ad.getDisplayName());
		
		List<AcePropertyDescriptor> adChildren = ad.getChildren();
		if (adChildren == null) {
			ap.setChildren(new ArrayList());
		}
		else {
			List<AceProperty> apChildren = new ArrayList<AceProperty>();
			for (AcePropertyDescriptor adChild: adChildren) {
				apChildren.add(createAceProperty(adChild, id));
			}
			
			ap.setChildren((List) apChildren);
		}
		
		return ap;
	}
	
	public static class AceProperty extends AcePropertyDescriptor {
		Ace ace;
		String id;
		
		public AceProperty(Ace ace, String id) {
			super();
			this.ace = ace;
			this.id = id;
		}
		
		public String getId() {
			return id;
		}

		public Integer getValue() {
			return ace.get(getName());
		}
		
		public void setValue(Integer value) {
			if (value != null) {
				ace.put(getName(), value);
			}
		}
		
		public boolean getGranted() {
			Integer i = ace.get(getName());
			return i != null ? (i == Ace.GRANTED) : false;
		}
		
		public void setGranted(boolean granted) {
			
		}
		
		public boolean getDenied() {
			Integer i = ace.get(getName());
			return i != null ? (i == Ace.DENIED) : false;
		}
		
		public void setDenied(boolean denied) {
			
		}
	}
	
	BoundChildrenTreeContentProvider acePropertiesProvider;
    public NodeTreeContentProvider getAcePropertiesTree() throws Exception {
    	if (acePropertiesProvider == null) {
    		AceProperty[] aceProperties = getAceProperties();
    		acePropertiesProvider = new BoundChildrenTreeContentProvider(aceProperties, "aceProperty",
    	            "#{aceProperty.id}", "#{aceProperty.children}");
    		
    		acePropertiesProvider.setOpenToDepth(99);
    	}
        
    	return acePropertiesProvider;
    }
	
	public void grantAll() throws Exception {
		AceProperty[] aceProperties = getAceProperties();
		for (AceProperty ap: aceProperties) {
			setValue(ap, Ace.GRANTED);
		}
	}
	
	public void denyAll() throws Exception {
		AceProperty[] aceProperties = getAceProperties();
		for (AceProperty ap: aceProperties) {
			setValue(ap, Ace.DENIED);
		}
	}
	
	public String getParentsList() throws Exception {
		Object obj = resolveExpression("#{aceProperty.parent}");
		if (obj instanceof AcePropertyDescriptor) {
			AcePropertyDescriptor parent = ((AcePropertyDescriptor) obj);
			StringBuffer parentsList = new StringBuffer();
			while (parent != null) {
				if (parentsList.length() > 0) {
					parentsList.append(",");
				}
				
				// determine ID from the name
				String id = acePropertiesIDMap.get(parent.getName());
				parentsList.append("'").append(id).append("'");
				parent = parent.getParent();
			}
			
			return parentsList.toString();
		}
		else {
			return "";
		}
	}
	
	public String getCurrentPrincipalDenyLabel() throws Exception {
		return getPrincipalLabel("label.deny.all", null);
	}
	
	public String getCurrentPrincipalGrantLabel() throws Exception {
		return getPrincipalLabel("label.grant.all", null);
	}
	
	public String getCurrentPrincipalDisplayName() throws Exception {
		return getPrincipalLabel("label", null);
	}
	
	protected String getPrincipalLabel(String resourseKey, String defaultKey) throws Exception {
		if (selectedPrincipals != null && selectedPrincipals.length > 0) {
			IPrincipalProvider pm = PrincipalModelFactory.createPrincipalModel(selectedPrincipals[0]);
			if (selectedPrincipals.length == 1) {
				return 	(String) pm.getDisplayName();
			}
			else {
				return 	(String) pm.getDisplayName();
			}
		}
		else {
			if (StringTools.notEmpty(getWmUsersList().getPrincipalID())) {
				IPrincipalProvider pm = PrincipalModelFactory.createPrincipalModel(getWmUsersList().getPrincipalID());
				return 	(String) pm.getDisplayName();
			}
			else {
				return 	 "" ;
			}
		}
	}
	
	public String applyAce() throws Exception {
		WmUsersListDefaultviewView dv = (WmUsersListDefaultviewView) resolveExpression("#{WmUsersListDefaultviewView}");
		
		// add these principals
		if (selectedPrincipals != null) {
			for (String principalID: selectedPrincipals) {
				dv.addPrincipal(principalID, ace);
			}			
		}
		else {
			// update ace
			dv.setAce(ace);
		}
		return "default";
	}
	
	private void setValue(AceProperty ap, Integer value) {
		if (ap.isAllowValue()) {
			ap.setValue(value);
		}
		
		List<AceProperty> children = (List)ap.getChildren();
		for (AceProperty apChild: children) {
			setValue(apChild, value);
		}
	}
    
	
}