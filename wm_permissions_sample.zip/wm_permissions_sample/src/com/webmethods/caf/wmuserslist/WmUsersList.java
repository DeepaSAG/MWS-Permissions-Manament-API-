/**
 * 
 */
package com.webmethods.caf.wmuserslist;

/**
 * @author bggov
 *
 */

import javax.portlet.PortletPreferences;

public class WmUsersList  extends   com.webmethods.caf.faces.bean.BaseFacesPreferencesBean {

	private com.webmethods.caf.Wm_permissions_sample wm_permissions_sample = null;
	/**
	 * List of portlet preference names
	 */
	public static final String[] PREFERENCES_NAMES = new String[] {
		"resourcesIDs", "resourceType", "returnUrl", "invocationID", "renderer", "principalID"
	};
	/**
	 * Create new preferences bean with list of preference names
	 */
	public WmUsersList() {
		super(PREFERENCES_NAMES);
	}
	
	/**
	 * Call this method in order to persist
	 * Portlet preferences
	 */
	public void storePreferences() throws Exception {
		updatePreferences();
		PortletPreferences preferences = getPreferences();
		preferences.store();
	}

	public com.webmethods.caf.Wm_permissions_sample getWm_permissions_sample()  {
		if (wm_permissions_sample == null) {
		    wm_permissions_sample = (com.webmethods.caf.Wm_permissions_sample)resolveExpression("#{Wm_permissions_sample}");
		}
		return wm_permissions_sample;
	}
	
	/**
	 * The algorithm for this 'smart' preference getter is:
	 * 1) Check the Request Map (skip this step if it isn't a 'smart' preference)
	 * 2) Check the Member variable
	 * 3) Fall back to the PortletPreferences
	 */
	public String getResourcesIDs() throws Exception {
		return (String) getPreferenceValue("resourcesIDs", String.class);
	}

	/**
	 * Invoke {@link #storePreferences} to persist these changes
	 */
	public void setResourcesIDs(String resourcesIDs) throws Exception {
		setPreferenceValue("resourcesIDs", resourcesIDs);
	}
	
	/**
	 * The algorithm for this 'smart' preference getter is:
	 * 1) Check the Request Map (skip this step if it isn't a 'smart' preference)
	 * 2) Check the Member variable
	 * 3) Fall back to the PortletPreferences
	 */
	public String getResourceType() throws Exception {
		return (String) getPreferenceValue("resourceType", String.class);
	}

	/**
	 * Invoke {@link #storePreferences} to persist these changes
	 */
	public void setResourceType(String resourceType) throws Exception {
		setPreferenceValue("resourceType", resourceType);
	}

	/**
	 * The algorithm for this 'smart' preference getter is:
	 * 1) Check the Request Map (skip this step if it isn't a 'smart' preference)
	 * 2) Check the Member variable
	 * 3) Fall back to the PortletPreferences
	 */
	public String getReturnUrl() throws Exception {
		return (String) getPreferenceValue("returnUrl", String.class);
	}

	/**
	 * Invoke {@link #storePreferences} to persist these changes
	 */
	public void setReturnUrl(String returnUrl) throws Exception {
		setPreferenceValue("returnUrl", returnUrl);
	}

	/**
	 * The algorithm for this 'smart' preference getter is:
	 * 1) Check the Request Map (skip this step if it isn't a 'smart' preference)
	 * 2) Check the Member variable
	 * 3) Fall back to the PortletPreferences
	 */
	public String getPrincipalID() throws Exception {
		return (String) getPreferenceValue("principalID", String.class);
	}

	/**
	 * Invoke {@link #storePreferences} to persist these changes
	 */
	public void setPrincipalID(String principalID) throws Exception {
		setPreferenceValue("principalID", principalID);
	}

	/**
	 * The algorithm for this 'smart' preference getter is:
	 * 1) Check the Request Map (skip this step if it isn't a 'smart' preference)
	 * 2) Check the Member variable
	 * 3) Fall back to the PortletPreferences
	 */
	public String getInvocationID() throws Exception {
		return (String) getPreferenceValue("invocationID", String.class);
	}

	/**
	 * Invoke {@link #storePreferences} to persist these changes
	 */
	public void setInvocationID(String invocationID) throws Exception {
		setPreferenceValue("invocationID", invocationID);
	}

	/**
	 * The algorithm for this 'smart' preference getter is:
	 * 1) Check the Request Map (skip this step if it isn't a 'smart' preference)
	 * 2) Check the Member variable
	 * 3) Fall back to the PortletPreferences
	 */
	public Boolean getRenderer() throws Exception {
		return (Boolean) getPreferenceValue("renderer", Boolean.class);
	}

	/**
	 * Invoke {@link #storePreferences} to persist these changes
	 */
	public void setRenderer(Boolean renderer) throws Exception {
		setPreferenceValue("renderer", renderer);
	}

	/**
	 * Invoke {@link #storePreferences} to persist these changes
	 */
	public void setRenderer(String renderer) throws Exception {
		setPreferenceValue("renderer", renderer);
	}
}