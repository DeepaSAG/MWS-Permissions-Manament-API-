/**
 * 
 */
package com.webmethods.caf.wmuserslist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.faces.convert.Converter;
import javax.jcr.PathNotFoundException;
import javax.servlet.http.HttpSessionBindingEvent;

import com.webmethods.caf.common.ListTools;
import com.webmethods.caf.common.ObjectUtil;
import com.webmethods.caf.faces.data.dir.IPrincipalProvider;
import com.webmethods.caf.faces.data.dir.PrincipalModel;
import com.webmethods.caf.faces.data.dir.PrincipalModelFactory;
import com.webmethods.caf.faces.data.portal.PortalContainerModel;
import com.webmethods.caf.faces.data.portal.PortalItemModel;
import com.webmethods.portal.service.access.Ace;
import com.webmethods.portal.service.access.AceSet;
import com.webmethods.portal.service.access.AclManagerFactory;
import com.webmethods.portal.service.access.IAclManager;
import com.webmethods.portal.service.access.IAclResource;
import com.webmethods.portal.service.access.impl.BaseAclManager;
import com.webmethods.portal.service.meta2.IXTypeService;
import com.webmethods.portal.service.meta2.thing.IThingID;
import com.webmethods.portal.service.meta2.type.IThingType;
import com.webmethods.portal.system.PortalSystem;
import com.webmethods.rtl.util.StringTools;
import com.webmethods.sc.directory.DirectorySystemFactory;
import com.webmethods.sc.directory.IDirectorySession;
import com.webmethods.sc.directory.IDirectoryUser;

/**
 * @author bggov
 *
 */

public class WmUsersListDefaultviewView  extends   com.webmethods.caf.faces.bean.BasePageBean {

	/**
	 * Determines if a de-serialized file is compatible with this class.
	 *
	 * Maintainers must change this value if and only if the new version
	 * of this class is not compatible with old versions. See Sun docs
	 * for <a href=http://java.sun.com/j2se/1.5.0/docs/guide/serialization/spec/version.html> 
	 * details. </a>
	 */
	private static final long serialVersionUID = 1L;
	private static final String[][] INITIALIZE_PROPERTY_BINDINGS = new String[][] {
	};
	private com.webmethods.caf.wmuserslist.WmUsersList wmUsersList = null;

	/**
	 * Initialize page
	 */
	public String initialize() {
		try {
		    resolveDataBinding(INITIALIZE_PROPERTY_BINDINGS, null, "initialize", true, false);
			if ("defaultForm:Permissions".equals(currentTab) && isSecurityRealmExist())
				currentTab = "defaultForm:SecurityRealm";

			return OUTCOME_OK;
		} catch (Exception e) {
			error(e);
			log(e);
			return OUTCOME_ERROR; 
		}	
	}

	public com.webmethods.caf.wmuserslist.WmUsersList getWmUsersList()  {
		if (wmUsersList == null) {
		    wmUsersList = (com.webmethods.caf.wmuserslist.WmUsersList)resolveExpression("#{WmUsersList}");
		}
		return wmUsersList;
	}
/* ------------------------------------------------------ */ 
    private Converter uidConverter;

	@Override
	protected void beforeRenderResponse() {
		super.beforeRenderResponse();
		
		// capture mode
		String mode = (String) resolveExpression("#{param['mode']}");
		if (mode != null) {
			this.mode = mode;
		}
		
		// capture returnUrl if there is one
		if (StringTools.isEmpty(returnUrl)) {
			returnUrl = (String) resolveExpression("#{param['cancelUrl']}");
			if (!StringTools.isEmpty(returnUrl)) {
				this.mode = "permission_renderer";
			}
		}
		
		
		try {
		    if (!ObjectUtil.equal(currentInvocationID, getWmUsersList().getInvocationID())) {
				currentInvocationID = getWmUsersList().getInvocationID();
		    	reset();
		    }
		} catch (Exception e) {
			error(e);
			log(e);
		}
		
	}
	
	public void reset() throws Exception {
		aclResources = null;
		recursiveAcls = false;
		recursiveAuthScheme = false;
		recursiveSecurityRealm = false;
		principals = new ArrayList<String>();
		principalsAcls = new HashMap<String, Ace>();
		principalsAclsCache = new HashMap<String, Ace>();
		principalModels = null;
		principalModelsProvider = null;
		getWmUsersList().setPrincipalID(null);
		securityRealmID = null;
		ownerID = null;
		currentTab = "defaultForm:Permissions";
		deletedPrincipalModels.clear();
	}
	
	public boolean isRecursiveAcls() {
		return recursiveAcls;
	}

	public void setRecursiveAcls(boolean recursive) {
		this.recursiveAcls = recursive;
	}
	
	public boolean isRecursiveAuthScheme() {
		return recursiveAuthScheme;
	}

	public void setRecursiveAuthScheme(boolean recursiveAuthScheme) {
		this.recursiveAuthScheme = recursiveAuthScheme;
	}

	public boolean isRecursiveSecurityRealm() {
		return recursiveSecurityRealm;
	}

	public void setRecursiveSecurityRealm(boolean recursiveSecurityRealm) {
		this.recursiveSecurityRealm = recursiveSecurityRealm;
	}



	String returnUrl = null;
	public String getReturnUrl() throws Exception {
		return returnUrl;
	}
	
	String mode = "permission_manage";
	public String getMode() {
		return mode;
	}

	public void returnBack() throws Exception {
		if (StringTools.notEmpty(returnUrl)) {
			getFacesContext().getExternalContext().redirect(returnUrl);
		}
	}

	IAclManager aclManager;
	public IAclManager getAclManager() throws Exception {
		String resourceType = getWmUsersList().getResourceType();
		if (aclManager == null || (resourceType != null && !aclManager.getResourceType().equals(resourceType))) {
			if (aclManager != null) {
				aclManager.release();
			}
			
			if (StringTools.isEmpty(resourceType)) {
				List<String> resourceIDs = getAclResourcesIDs();
				if (resourceIDs.size() > 0) {
					String resourceID = resourceIDs.get(0);
					IThingID thingID = (IThingID) PortalSystem.getPortalSystem().acquireURI(resourceID);
					if (thingID != null) {
						// determine xtype to use 
						IXTypeService xtypeService = thingID.getMetaContext().getXTypeService();
						int typeID = thingID.getTypeID();
						if (typeID == IThingType.XTYPE) {
							resourceType = IAclManager.TYPE_MWS_XTYPE;
						}
						else if (xtypeService.getXTypeName(thingID.getXTypeID()).equals("wm_xt_workspace")) {
							resourceType = IAclManager.TYPE_MWS_WORKSPACE;
						}
						else if (xtypeService.getXTypeName(thingID.getXTypeID()).equals("wm_securityrealm")) {
							resourceType = IAclManager.TYPE_MWS_SECURITYREALM;
						}
					}
				}
			}
			
			// get default one
			if (StringTools.isEmpty(resourceType)) {
				resourceType = IAclManager.TYPE_MWS_OBJECT;
			}
			
			aclManager = AclManagerFactory.createAclManager(resourceType);
		}
		
		return aclManager;
	}

	@Override
	public void valueUnbound(HttpSessionBindingEvent event) {
		super.valueUnbound(event);
		if (aclManager != null) {
			aclManager.release();
		}
	}
	
	boolean recursiveAcls = false;
	boolean recursiveAuthScheme = false;
	boolean recursiveSecurityRealm = false;
	
	List<String> aclResources = null;
	public List<String> getAclResourcesIDs() throws Exception {
		// get from request params
		String resourceID = (String) resolveExpression("#{param['resourceID']}");
		if (StringTools.notEmpty(resourceID)) {
			reset();
			aclResources = new ArrayList(Collections.singletonList(resourceID));
		}
		
		if (aclResources == null) {
			aclResources = new ArrayList(ListTools.stringToList(getWmUsersList().getResourcesIDs()));
			
			// use current.resource otherwise
			if (aclResources.isEmpty()) {
				IThingID thingID = (IThingID) PortalSystem.getPortalSystem().acquireURI("current.resource");
				if (thingID != null) {
					aclResources = new ArrayList(Collections.singletonList(thingID.toString()));
				}
			}
		}
		
		return aclResources;
	}
	
	public String getResourceID() throws Exception {
		return getAclResourcesIDs().get(0);
	}
	
	String currentInvocationID;
	List<String> principals;
	Map<String, Ace> principalsAcls;
	Map<String, Ace> principalsAclsCache;
	List<PrincipalModel> principalModels;
	List<PrincipalModel> deletedPrincipalModels = new ArrayList<PrincipalModel>();
	
	private com.webmethods.caf.faces.data.object.SelectableListTableContentProvider principalModelsProvider = null;
	private static final String[][] PRINCIPALMODELSPROVIDER_PROPERTY_BINDINGS = new String[][] {
		{"#{principalModelsProvider.rowVariable}", "principalModel"},
		{"#{principalModelsProvider.rowIdBinding}", "#{principalModel.principalURI}"},
		{"#{principalModelsProvider.list}", "#{WmUsersListDefaultviewView.principalModels}"},
	};
	public List<PrincipalModel> getPrincipalModels() throws Exception {
		if (principalModels == null) {
			loadAcls();
			principalModels = new ArrayList<PrincipalModel>();
			for (String principalID: principals) {
				IPrincipalProvider p = PrincipalModelFactory.createPrincipalModel(principalID);
				principalModels.add((PrincipalModel) p);
			}
		}
		
		return principalModels;
	}
	
	public void loadAcls() throws Exception {
		principals = new ArrayList<String>();
		principalsAcls = new HashMap<String, Ace>();
		principalsAclsCache = new HashMap<String, Ace>();
		
		List<String> resourceIDs = getAclResourcesIDs();
		IAclManager aclManager = getAclManager();
		for (String resourceID: resourceIDs) {
			AceSet aceSet = aclManager.getAceSetForResource(resourceID);
			for (Ace ace: aceSet) {
				String principalID = ace.getPrincipalID();
				
				if (!principals.contains(principalID)) {
					principals.add(principalID);
					principalsAcls.put(principalID, ace);
					Ace clonedAce = new Ace(ace.getPrincipalID());
					clonedAce.putAll(ace);
					principalsAclsCache.put(principalID, clonedAce);
				}
				else {
					// if there is already ace for this principal, then simply update
					Ace existingAce = principalsAcls.get(principalID);
					existingAce.putAll(ace);
					existingAce = principalsAclsCache.get(principalID);
					existingAce.putAll(ace);
				}
			}
		}
	}
	
	public void closeAction() throws Exception {
		principals = null;
		principalsAcls = null;
		principalModels = null;
		principalModelsProvider = null;
		
		String returnUrl = getWmUsersList().getReturnUrl();
		if (StringTools.notEmpty(returnUrl)) {
			getFacesContext().getExternalContext().redirect(returnUrl);
		}
	}

	public com.webmethods.caf.faces.data.object.SelectableListTableContentProvider getPrincipalModelsProvider()  {
		if (principalModelsProvider == null) {
		    principalModelsProvider = (com.webmethods.caf.faces.data.object.SelectableListTableContentProvider)resolveExpression("#{PrincipalModelsProvider}");
		}
	
	    resolveDataBinding(PRINCIPALMODELSPROVIDER_PROPERTY_BINDINGS, principalModelsProvider, "principalModelsProvider", false, false);
		return principalModelsProvider;
	}
	
	String[] principalIDs;

	public String[] getPrincipalID() {
		return principalIDs;
	}

	public void setPrincipalID(String[] principalIDs) {
		this.principalIDs = principalIDs;
	}
	
	public void addPrincipal(String principalID, Ace ace) throws Exception {
		Ace newAce = (Ace) ace.clone();
		newAce.setPrincipalID(principalID);
		
		if (principalsAcls.containsKey(principalID)) {
			principalsAcls.put(principalID, newAce);
			return;
		}
		
		principals.add(principalID);
		principalsAcls.put(principalID, newAce);
		
		PrincipalModel pm = (PrincipalModel) PrincipalModelFactory.createPrincipalModel(principalID);
		principalModels.add(pm);
		
		principalIDs = null;
		principalModelsProvider.setList(null);
	}
	
	public void removePrincipal() throws Exception {
		List<Object> selectedList = getPrincipalModelsProvider().getSelectedRows();
		for (Object selected: selectedList) {
			// delete principal from each resource
			PrincipalModel pm = (PrincipalModel) selected;
			deletedPrincipalModels.add(pm);
			principalModels.remove(pm);
			principalsAclsCache.remove(pm.getPrincipalURIAsString());
			principalsAcls.remove(pm.getPrincipalURIAsString());
			principals.remove(pm.getPrincipalURIAsString());
		}

		principalModelsProvider.setList(null);
		
		//MWS-4757 - we just remove the select rows, so we have to clear out the selected row ids from
		//  the provider
		getPrincipalModelsProvider().setRowSelectedIds(Collections.emptyList());
	}
	
	public String selectPrincipal() throws Exception {
		PrincipalModel pm = (PrincipalModel) getPrincipalModelsProvider().getCurrentRow();
		getWmUsersList().setPrincipalID(pm.getPrincipalURI().toString());
		WmUsersEditPermissionsView pv = (WmUsersEditPermissionsView) resolveExpression("#{WmUsersEditPermissionsView}");
		if (pv != null) {
			pv.setAce(getAce());
			pv.setAclManager((BaseAclManager) getAclManager());
			pv.setResources((ArrayList<String>) getAclResourcesIDs());
			pv.setSelectedPrincipals(null);
		}
		
		return "permissions";
	}
	
	public boolean isSelectedPrincipal() throws Exception {
		String rowID = String.valueOf(resolveExpression("#{principalModel.principalURI}"));
		return ObjectUtil.equal(rowID, getWmUsersList().getPrincipalID());
	}
	
	public boolean isSpecialStylePrincipal() throws Exception {
		getPrincipalModels();
		String rowID = String.valueOf(resolveExpression("#{principalModel.principalURI}"));
		if (StringTools.isEmpty(rowID)) {
			return false;
		}
		
		return principalsAcls.get(rowID) == null || principalsAcls.get(rowID).isEmpty();
	}
	
	public String getPrincipalDisplayStyle() throws Exception {
		StringBuffer b = new StringBuffer();
		if (isSelectedPrincipal()) {
			b.append("font-weight: bold;");
		}
		
		if (isSpecialStylePrincipal()) {
			b.append("font-style: italic;");
		}
		
		return b.toString();
	}
	
	public String getPrincipalPermissionsName() throws Exception {
		String principalID = String.valueOf(resolveExpression("#{principalModel.principalURI}"));
		Ace ace = principalsAcls.get(principalID);
		return getAclManager().getAceDisplayName(getAclResourcesIDs(), ace);
	}
	
	String currentTab = "defaultForm:Permissions";

	public String getCurrentTab() {
		return currentTab;
	}

	public void setCurrentTab(String currentTab) {
		this.currentTab = currentTab;
	}
	
	String securityRealmID;
	String securityRealmURL = "";
	public String getSecurityRealmURL() throws Exception {
		if (!StringTools.notEmpty(securityRealmURL)) {
			getSecurityRealmName();
		}
		return securityRealmURL;
	}
	
	private com.webmethods.caf.jcr.faces.bean.RepositorySessionManager repositorySessionManager = null;
	private static final String[][] REPOSITORYSESSIONMANAGER_PROPERTY_BINDINGS = new String[][] {
		{"#{repositorySessionManager.expireWithPageFlow}", "true"},
	};
	public String getSecurityRealmName() throws Exception {
		String sid = getSecurityRealmID();
		if (StringTools.notEmpty(sid)) {
			PortalItemModel pim = new PortalItemModel();
			pim.setItemID(securityRealmID);
			securityRealmURL = pim.getURL();
			return pim.getName();
		}
		else {
			return (String) getWmUsersList().getPortletResourcesProvider().getValue("label.no.security.realm");
		}
	}
	
	public String getSecurityRealmID() throws Exception {
		if (securityRealmID == null) {
			List<String> resourceIDs = getAclResourcesIDs();
			// grab securityRealm only from 1st resource selected
			if (resourceIDs.size() > 0) {
				securityRealmID = getAclManager().getResourceSecurityRealm(resourceIDs.get(0));
				if (securityRealmID == null) {
					securityRealmID = "";
				}
			}
		}
		
		return securityRealmID;
	}
	
	public boolean isSecurityRealmExist() {
		try {
			return !"".equals(getSecurityRealmID());
		} catch (Exception e) {
			error(e);
			return false;
		}
		
	}

	public void setSecurityRealmID(String securityRealmID) {
		this.securityRealmID = securityRealmID;
	}
	
	public void applySecurityRealm() throws Exception {
		IAclManager am = getAclManager();
		List<String> resourceIDs = getAclResourcesIDs();
		for (String resourceID: resourceIDs) {
			am.applySecurityRealmToResource(resourceID, securityRealmID, recursiveSecurityRealm);
		}
	}
	
	public void removeSecurityRealm() throws Exception {
		securityRealmID = "";
	}
	
	String ownerID;
	public String getOwnerID() throws Exception {
		if (ownerID == null) {
			List<String> resourceIDs = getAclResourcesIDs();
			// grab owner only from 1st resource selected
			if (resourceIDs.size() > 0) {
				ownerID = getAclManager().getResourceOwner(resourceIDs.get(0));
			}
		}
		
		return ownerID;
	}

	public void setOwnerID(String ownerID) {
		this.ownerID = ownerID;
	}
	
	public String getOwnerName() throws Exception {
		String ownerID = getOwnerID();
		if (ownerID != null) {
			IDirectorySession s = DirectorySystemFactory.getDirectorySystem().createSession();
			IDirectoryUser principal = (IDirectoryUser) s.lookupPrincipalByID(ownerID);
			return principal.getFullName();
		}
		else {
			return "";
		}
	}
	
	public void applyOwner() throws Exception {
		IAclManager am = getAclManager();
		List<String> resourceIDs = getAclResourcesIDs();
		for (String resourceID: resourceIDs) {
			am.applyOwnerToResource(resourceID, ownerID);
		}
	}

	public com.webmethods.caf.jcr.faces.bean.RepositorySessionManager getRepositorySessionManager()  {
		if (repositorySessionManager == null) {
		    repositorySessionManager = (com.webmethods.caf.jcr.faces.bean.RepositorySessionManager)resolveExpression("#{repositorySessionManager}");
		}
	
	    resolveDataBinding(REPOSITORYSESSIONMANAGER_PROPERTY_BINDINGS, repositorySessionManager, "repositorySessionManager", false, false);
		return repositorySessionManager;
	}
	
	public Ace getAce() throws Exception {
		getPrincipalModels();
		String principalID = getWmUsersList().getPrincipalID();
		return principalsAcls.get(principalID);
	}
	
	public void setAce(Ace ace) throws Exception {
		getPrincipalModels();
		String principalID = getWmUsersList().getPrincipalID();
		principalsAcls.put(principalID, ace);
	}
	
	public String applyPermissions() throws Exception {
		// remove principals
		for (PrincipalModel pm: deletedPrincipalModels) {
			String principalID = pm.getPrincipalURI().toString();
			List<String> resourceIDs = getAclResourcesIDs();
			for (String resourceID: resourceIDs) {
				getAclManager().deleteAceFromResource(resourceID, principalID, recursiveAcls);
			}
		}
		
		deletedPrincipalModels.clear();
		
		// add/update principals
		for (String principalID: principals) {
			Ace cachedAce = principalsAclsCache.get(principalID);
			Ace appliedAce = principalsAcls.get(principalID);
			// skip over aces which did not change
			if (appliedAce.equals(cachedAce)) {
				continue;
			}
			
			List<String> resourceIDs = getAclResourcesIDs();
			for (String resourceID: resourceIDs) {
				getAclManager().applyAceToResource(resourceID, appliedAce, recursiveAcls);
			}
		}
		
		// reload everything
		principalModels = null;
		principalModelsProvider = null;
		
		return "ok";
	}
	
	public void applyAuthScheme() throws Exception {
		List<String> resourceIDs = getAclResourcesIDs();
		for (String resourceID: resourceIDs) {
			getAclManager().applyAuthSchemeToResource(resourceID, authScheme, recursiveAuthScheme);
		}
	}
	
	String authScheme = null;
	Map availableAuthSchemes = null;
	
	public String getAuthScheme() throws Exception {
		if (authScheme == null) {
			// grab securityRealm only from 1st resource selected
			List<String> resourceIDs = getAclResourcesIDs();
			if (resourceIDs.size() > 0) {
				authScheme = getAclManager().getResourceAuthScheme(resourceIDs.get(0));
			}
			else {
				authScheme = "default";
			}
		}
		return authScheme;
	}

	public void setAuthScheme(String authScheme) {
		this.authScheme = authScheme;
	}

	public Map getAvailableAuthSchemes() throws Exception {
		if (availableAuthSchemes == null) {
			availableAuthSchemes = new HashMap();
			
			PortalContainerModel pc = new PortalContainerModel();
			pc.setContainerID("folder.auth.schemes");
			pc.setRowIndex(0);
			while (pc.isRowAvailable()) {
				PortalItemModel pim = (PortalItemModel) pc.getCurrentRow();
				availableAuthSchemes.put(pim.getDescription(), pim.getName());
				pc.setRowIndex(pc.getRowIndex() + 1);
			}
		}
		
		return availableAuthSchemes;
	}
	
	public boolean isCanSetPermissions() throws Exception {
		List<String> resources = getAclResourcesIDs();
		for (String resourceID: resources) {
			if (!getAclManager().isCanSetPermissions(resourceID)) {
				return false;
			}
		}
		
		return true;
	}
	
	public void grantAll() throws Exception {
		Ace ace = getAce();
		Iterator<Entry<String, Integer>> it = ace.entrySet().iterator();
		while (it.hasNext()) {
			Entry<String, Integer> e = it.next();
			e.setValue(Ace.GRANTED);
		}
	}
	
	public void denyAll() throws Exception {
		Ace ace = getAce();
		Iterator<Entry<String, Integer>> it = ace.entrySet().iterator();
		while (it.hasNext()) {
			Entry<String, Integer> e = it.next();
			e.setValue(Ace.DENIED);
		}
	}
	
	public boolean isShowTabset() throws Exception {
		IAclManager am = getAclManager();
		return am.isSupportAuthScheme() || am.isSupportSecurityRealm() || am.isSupportSetOwner();
	}
	
	public String getEditPermissionsText() throws Exception {
		int size = getAclResourcesIDs().size();
		String label = null;
		if (size == 0) {
			return "";
		}
		
		IAclResource firstResource = null;
		
		try{
		    firstResource = getAclManager().getAclResource(getAclResourcesIDs().get(0));
		}
		catch (PathNotFoundException e) {
		    log(e);
		}
		
		if (firstResource == null) {
			return "";
		}
		
		if (size > 1) {
			label = (String) getWmUsersList().getPortletResourcesProvider().getValue("label.multiple.objects", 
					new Object[] {firstResource.getName(), String.valueOf(size)});
		}
		else {
			label = (String) getWmUsersList().getPortletResourcesProvider().getValue("label.one.object", 
					new Object[] {firstResource.getName()});
		}
		
		return label;
	}
	
	public Converter getConverter() {
        if (uidConverter == null) {
            uidConverter = new UidUrlEncodingConverter();
        }
        return uidConverter;        
    }
}